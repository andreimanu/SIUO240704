package aima.core.agent;

/**
 * An interface used to indicate a possible state of an Environment.
 * 
 * @author Ciaran O'Reilly
 */
public interface EnvironmentState {

}
