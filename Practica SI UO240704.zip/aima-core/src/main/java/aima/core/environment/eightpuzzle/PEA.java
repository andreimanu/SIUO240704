package aima.core.environment.eightpuzzle;

public class PEA extends ManhattanHeuristicFunction {
	private double eps;
	public PEA(EightPuzzleGoalTest goal, double eps) {
		super(goal);
		this.eps = eps;
	}
	@Override
	public double h(Object state) {
		return (1+eps)*super.h(state);
	}
}
