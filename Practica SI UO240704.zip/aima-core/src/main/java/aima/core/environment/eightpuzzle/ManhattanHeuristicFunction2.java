package aima.core.environment.eightpuzzle;

public class ManhattanHeuristicFunction2 extends ManhattanHeuristicFunction {

	public ManhattanHeuristicFunction2(EightPuzzleGoalTest goal) {
		super(goal);
	}
	
	@Override
	public double h(Object state) {
		return Math.max(1.31 * super.h(state) - 2.19, super.h(state));
	}

}
